package com.irissouza.app

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val youtube = "https://www.youtube.com/@irissouza1"
    private val site = "https://irissouzafrp.com"
    private val loja = "https://www.magazinevoce.com.br/magazinecanalirissouza/"
    private val instagram = "https://www.instagram.com/canalirissouza"
    private val facebook = "https://fb.me/irissouza01"

    private val bg = Color.rgb(10, 10, 14)
    private val card = Color.rgb(22, 22, 29)
    private val white = Color.WHITE
    private val muted = Color.rgb(175, 175, 188)
    private val accent = Color.rgb(255, 193, 7)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        scroll.addView(root)

        // Logo / brand
        val logo = TextView(this).apply {
            text = "IS"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(accent, Color.rgb(255, 224, 110))).apply {
                shape = GradientDrawable.OVAL
            }
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(78), dp(78)).apply { bottomMargin = dp(14) })

        root.addView(TextView(this).apply {
            text = "IRIS SOUZA"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(white)
        }, lpWrap())

        root.addView(TextView(this).apply {
            text = "Tecnologia • Economia • Geopolítica • Entretenimento"
            textSize = 13.5f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(20))
        }, lpWrap())

        val cardLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(card, 22)
        }
        root.addView(cardLayout, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        addButton(cardLayout, "▶", "Vídeos do YouTube", youtube)
        addButton(cardLayout, "🛍", "Loja virtual", loja)
        addButton(cardLayout, "🌐", "Meu site", site)
        addButton(cardLayout, "◎", "Instagram", instagram)
        addButton(cardLayout, "f", "Facebook", facebook)

        val share = TextView(this).apply {
            text = "↗  Compartilhar"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(accent)
            setPadding(0, dp(13), 0, dp(13))
            setOnClickListener { shareApp() }
            isClickable = true
        }
        root.addView(share, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })

        root.addView(TextView(this).apply {
            text = "Acompanhe o Canal Iris Souza e fique por dentro das novidades."
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(dp(8), 0, dp(8), dp(6))
        }, lpWrap())

        root.addView(TextView(this).apply {
            text = "© Iris Souza"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(105, 105, 115))
        }, lpWrap())

        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, icon: String, label: String, url: String) {
        val button = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            background = rounded(Color.rgb(31, 31, 40), 16)
            isClickable = true
            isFocusable = true
            setOnClickListener { openUrl(url) }
            setOnTouchListener { v, event ->
                when (event.action) {
                    0 -> v.alpha = 0.72f
                    1, 3 -> v.alpha = 1f
                }
                false
            }
        }
        val iconView = TextView(this).apply {
            text = icon
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(accent)
        }
        button.addView(iconView, LinearLayout.LayoutParams(dp(38), -1))
        button.addView(TextView(this).apply {
            text = label
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(white)
        }, LinearLayout.LayoutParams(0, -1, 1f))
        button.addView(TextView(this).apply {
            text = "›"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(120, 120, 130))
        }, LinearLayout.LayoutParams(dp(30), -1))

        root.addView(button, LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(10) })
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) { }
    }

    private fun shareApp() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Conheça o aplicativo Iris Souza!")
        }
        startActivity(Intent.createChooser(intent, "Compartilhar aplicativo"))
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun lpWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
