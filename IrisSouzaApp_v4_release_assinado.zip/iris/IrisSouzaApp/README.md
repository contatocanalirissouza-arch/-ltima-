# Iris Souza App — Release assinado

Projeto Android preparado para gerar um APK **Release assinado** pelo GitHub Actions, usando somente o celular.

## 1. Criar a chave de assinatura

A chave é criada uma única vez. Em um computador ou ambiente Android que tenha o Java instalado, use:

```bash
keytool -genkeypair -v -keystore release.keystore -alias iris-souza -keyalg RSA -keysize 2048 -validity 10000
```

Guarde o arquivo `release.keystore` e as senhas em local seguro. **Não envie a chave para o repositório público.**

Para transformar a chave em Base64:

```bash
base64 -w 0 release.keystore
```

No GitHub, abra **Settings → Secrets and variables → Actions → New repository secret** e crie:

- `KEYSTORE_BASE64` = conteúdo Base64 do arquivo `release.keystore`
- `KEYSTORE_PASSWORD` = senha do keystore
- `KEY_ALIAS` = `iris-souza`
- `KEY_PASSWORD` = senha da chave

## 2. Gerar o APK pelo celular

Abra **Actions → Gerar APK Release assinado → Run workflow**.

Quando terminar, abra a execução e baixe o artefato:

`IrisSouzaApp-Release-Assinado`

Dentro dele estará o APK Release assinado.

### Importante

Faça backup do `release.keystore`. Para atualizações futuras do aplicativo, você deve usar **a mesma chave de assinatura**. Se perder a chave, poderá ter problemas para atualizar o mesmo aplicativo na Google Play.
